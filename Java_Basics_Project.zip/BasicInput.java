import java.util.Scanner;

public class BasicInput {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int age = sc.nextInt();
        String name = sc.next();

        System.out.println("Name: " + name);
        System.out.println("Age: " + age);

        sc.close();
    }
}
