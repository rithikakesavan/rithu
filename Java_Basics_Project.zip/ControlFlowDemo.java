import java.util.Scanner;

public class ControlFlowDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        if(n > 0)
            System.out.println("Positive");
        else if(n < 0)
            System.out.println("Negative");
        else
            System.out.println("Zero");

        switch(n) {
            case 1: System.out.println("One"); break;
            default: System.out.println("Other");
        }

        for(int i=1;i<=3;i++)
            System.out.println("For: " + i);

        int j=1;
        while(j<=3)
            System.out.println("While: " + j++);

        int k=1;
        do {
            System.out.println("DoWhile: " + k++);
        } while(k<=3);

        sc.close();
    }
}
