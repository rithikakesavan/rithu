public class MethodsDemo {

    static int add(int a, int b) {
        return a + b;
    }

    static double square(double n) {
        return n * n;
    }

    public static void main(String[] args) {
        System.out.println(add(10,20));
        System.out.println(square(5));
    }
}
