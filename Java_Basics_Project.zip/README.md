# Java Basics Programs

## Contents
1. BasicInput.java
2. ArraysDemo.java
3. ControlFlowDemo.java
4. MethodsDemo.java

## Concepts Covered
- int and String variables
- Scanner input
- Arrays
- if/else
- switch
- for loop
- while loop
- do-while loop
- Static methods
- Parameters and return values

## Compilation

Compile:
javac *.java

Run:
java BasicInput
java ArraysDemo
java ControlFlowDemo
java MethodsDemo

## GitHub Repository Structure

Java_Basics_Project/
├── BasicInput.java
├── ArraysDemo.java
├── ControlFlowDemo.java
├── MethodsDemo.java
└── README.md
