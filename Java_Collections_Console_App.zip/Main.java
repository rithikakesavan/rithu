import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StudentManager sm = new StudentManager();

        while(true) {
            System.out.println("\n1.Add Student");
            System.out.println("2.Display Students");
            System.out.println("3.Save");
            System.out.println("4.Load");
            System.out.println("5.Exit");

            try {
                int choice = sc.nextInt();

                switch(choice) {
                    case 1:
                        System.out.print("ID: ");
                        int id = sc.nextInt();
                        System.out.print("Name: ");
                        String name = sc.next();
                        sm.addStudent(id,name);
                        break;

                    case 2:
                        sm.displayStudents();
                        break;

                    case 3:
                        try {
                            sm.saveToFile();
                            System.out.println("Saved");
                        } catch(Exception e) {
                            System.out.println("File Error");
                        }
                        break;

                    case 4:
                        try {
                            sm.loadFromFile();
                            System.out.println("Loaded");
                        } catch(Exception e) {
                            System.out.println("File Error");
                        }
                        break;

                    case 5:
                        return;

                    default:
                        System.out.println("Invalid Choice");
                }
            }
            catch(Exception e) {
                System.out.println("Invalid Input");
                sc.nextLine();
            }
        }
    }
}
