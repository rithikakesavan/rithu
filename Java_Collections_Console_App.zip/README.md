# Java Collections Console App

## Features
- ArrayList for storing students
- HashMap for fast lookup
- File read/write using CSV
- Menu-driven console interface
- Exception handling using try-catch

## Files
- Student.java
- StudentManager.java
- Main.java
- README.md

## Compile
javac *.java

## Run
java Main

## Usage
1. Add Student
2. Display Students
3. Save Data to CSV
4. Load Data from CSV
5. Exit

## Concepts Used
- ArrayList
- HashMap
- File I/O
- Exception Handling
- Object-Oriented Programming
