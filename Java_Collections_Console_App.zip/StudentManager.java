import java.io.*;
import java.util.*;

public class StudentManager {
    ArrayList<Student> students = new ArrayList<>();
    HashMap<Integer,String> map = new HashMap<>();

    public void addStudent(int id, String name) {
        Student s = new Student(id,name);
        students.add(s);
        map.put(id,name);
    }

    public void displayStudents() {
        for(Student s : students)
            System.out.println(s);
    }

    public void saveToFile() throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter("students.csv"));
        for(Student s : students) {
            bw.write(s.toString());
            bw.newLine();
        }
        bw.close();
    }

    public void loadFromFile() throws IOException {
        students.clear();
        BufferedReader br = new BufferedReader(new FileReader("students.csv"));
        String line;

        while((line=br.readLine())!=null) {
            String[] data=line.split(",");
            addStudent(Integer.parseInt(data[0]),data[1]);
        }
        br.close();
    }
}
