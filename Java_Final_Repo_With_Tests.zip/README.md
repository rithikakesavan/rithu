# Java Final Repository

## Features
- Clean and refactored Java code
- Javadoc documentation
- JUnit 5 test cases
- GitHub-ready project structure

## Files
- Calculator.java
- CalculatorTest.java
- README.md

## Compile
javac Calculator.java

## Run Tests
Requires JUnit 5 dependency.

Example Maven Dependency:

<dependency>
  <groupId>org.junit.jupiter</groupId>
  <artifactId>junit-jupiter</artifactId>
  <version>5.10.2</version>
  <scope>test</scope>
</dependency>

## Screenshots
Add screenshots of:
1. Program execution
2. Test execution
3. GitHub repository page

## Test Cases
- testAdd()
- testSubtract()
- testMultiply()
