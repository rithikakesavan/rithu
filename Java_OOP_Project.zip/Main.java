public class Main {
    public static void main(String[] args) {

        Person p1 = new Student(101, "Ravi", 89.5);
        Person p2 = new Teacher(201, "Priya", "Java");

        p1.display();
        p2.display();

        Student s = new Student(102, "Arun", 95);
        s.display("Overloaded Method Example");

        Printable obj = s;
        obj.printDetails();
    }
}
