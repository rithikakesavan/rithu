# Java OOP Project

## Concepts Covered

### Classes
- Person class with private fields
- Constructors
- Getters and Setters

### Inheritance
- Student extends Person
- Teacher extends Person

### Polymorphism
- Method overriding (display())
- Method overloading (display(String))

### Interface
- Printable interface
- Implemented by Student class

## Compilation

javac *.java

## Run

java Main

## Project Structure

Java_OOP_Project/
├── Person.java
├── Student.java
├── Teacher.java
├── Printable.java
├── Main.java
└── README.md
