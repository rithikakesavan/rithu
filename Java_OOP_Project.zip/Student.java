public class Student extends Person implements Printable {
    private double marks;

    public Student(int id, String name, double marks) {
        super(id, name);
        this.marks = marks;
    }

    @Override
    public void display() {
        System.out.println("Student -> ID: " + getId() +
                ", Name: " + getName() +
                ", Marks: " + marks);
    }

    public void display(String message) {
        System.out.println(message);
        display();
    }

    @Override
    public void printDetails() {
        display();
    }
}
