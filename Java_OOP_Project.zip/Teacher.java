public class Teacher extends Person {
    private String subject;

    public Teacher(int id, String name, String subject) {
        super(id, name);
        this.subject = subject;
    }

    @Override
    public void display() {
        System.out.println("Teacher -> ID: " + getId() +
                ", Name: " + getName() +
                ", Subject: " + subject);
    }
}
